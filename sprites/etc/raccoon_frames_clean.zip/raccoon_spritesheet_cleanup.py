from PIL import Image, ImageDraw
import numpy as np
import cv2
import os, zipfile, json, shutil

src_path = "image(5).png"
src = Image.open(src_path).convert("RGBA")

CELL_W = 512
CELL_H = 220
COLS = 4
ROWS = 2
SOURCE_ROWS = [(80, 265), (325, 545)]
OUT_DIR = "raccoon_frames_clean"
shutil.rmtree(OUT_DIR, ignore_errors=True)
os.makedirs(OUT_DIR, exist_ok=True)

def remove_connected_light_background(crop: Image.Image) -> Image.Image:
    arr = np.array(crop.convert("RGBA"))
    r, g, b, a = arr[..., 0], arr[..., 1], arr[..., 2], arr[..., 3]
    bg_like = (
        (a > 0)
        & (r > 215) & (g > 210) & (b > 185)
        & ((r.astype(np.int16) - b.astype(np.int16)) < 50)
        & ((g.astype(np.int16) - b.astype(np.int16)) < 45)
        & ((r.astype(np.int16) - g.astype(np.int16)) < 30)
    )
    bg_like |= (
        (a > 0)
        & (r > 225) & (g > 225) & (b > 215)
        & ((np.maximum.reduce([r, g, b]).astype(np.int16)
            - np.minimum.reduce([r, g, b]).astype(np.int16)) < 50)
    )

    mask = bg_like.astype(np.uint8)
    n, labels = cv2.connectedComponents(mask, connectivity=4)
    border_labels = set()
    border_labels.update(np.unique(labels[0, :]).tolist())
    border_labels.update(np.unique(labels[-1, :]).tolist())
    border_labels.update(np.unique(labels[:, 0]).tolist())
    border_labels.update(np.unique(labels[:, -1]).tolist())
    border_labels.discard(0)
    if border_labels:
        arr[..., 3] = np.where(np.isin(labels, list(border_labels)), 0, a)
    return Image.fromarray(arr, "RGBA")

def remove_upper_label_components(frame: Image.Image, row_index: int) -> Image.Image:
    if row_index != 1:
        return frame
    arr = np.array(frame.convert("RGBA"))
    alpha = (arr[..., 3] > 0).astype(np.uint8)
    n, labels, stats, _ = cv2.connectedComponentsWithStats(alpha, connectivity=4)
    for lab in range(1, n):
        x, y, w, h, area = stats[lab]
        if (y + h) < 58 and area < 3000:
            arr[labels == lab, 3] = 0
    return Image.fromarray(arr, "RGBA")

sheet = Image.new("RGBA", (CELL_W * COLS, CELL_H * ROWS), (0, 0, 0, 0))
frame_paths = []
metadata = {
    "columns": COLS,
    "rows": ROWS,
    "frame_width": CELL_W,
    "frame_height": CELL_H,
    "sheet_width": CELL_W * COLS,
    "sheet_height": CELL_H * ROWS,
    "frames": []
}

frame_num = 1
for row_index, (y0, y1) in enumerate(SOURCE_ROWS):
    source_h = y1 - y0
    y_offset = CELL_H - source_h
    for col in range(COLS):
        x0 = col * CELL_W
        crop = src.crop((x0, y0, x0 + CELL_W, y1))
        crop = remove_connected_light_background(crop)
        frame = Image.new("RGBA", (CELL_W, CELL_H), (0, 0, 0, 0))
        frame.alpha_composite(crop, (0, y_offset))
        frame = remove_upper_label_components(frame, row_index)
        frame_path = f"{OUT_DIR}/raccoon_frame_{frame_num:02d}.png"
        frame.save(frame_path)
        frame_paths.append(frame_path)
        sheet_x = col * CELL_W
        sheet_y = row_index * CELL_H
        sheet.alpha_composite(frame, (sheet_x, sheet_y))
        metadata["frames"].append({
            "frame": frame_num,
            "sheet_x": sheet_x,
            "sheet_y": sheet_y,
            "width": CELL_W,
            "height": CELL_H,
            "source_crop": {"x": x0, "y": y0, "width": CELL_W, "height": source_h},
            "alignment": "bottom-aligned in fixed-size cell"
        })
        frame_num += 1

sheet.save("raccoon_spritesheet_clean.png")
with open("raccoon_spritesheet_metadata.json", "w", encoding="utf-8") as f:
    json.dump(metadata, f, indent=2)
with zipfile.ZipFile("raccoon_frames_clean.zip", "w", zipfile.ZIP_DEFLATED) as z:
    for p in frame_paths:
        z.write(p, arcname=os.path.basename(p))
    z.write("raccoon_spritesheet_metadata.json")
